<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8" />
	
				<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
		
            
            
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="http://blasusfoods.local/xmlrpc.php" />

	<title>blasusfoods | </title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="blasusfoods &raquo; Feed" href="http://blasusfoods.local/feed/" />
<link rel="alternate" type="application/rss+xml" title="blasusfoods &raquo; Comments Feed" href="http://blasusfoods.local/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/blasusfoods.local\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.3"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='layerslider-css' href='http://blasusfoods.local/wp-content/plugins/LayerSlider/assets/static/layerslider/css/layerslider.css?ver=6.11.5' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='http://blasusfoods.local/wp-includes/css/dist/block-library/style.min.css?ver=6.5.3' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='http://blasusfoods.local/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='marvy-custom-css' href='http://blasusfoods.local/wp-content/plugins/marvy-animation-addons-for-elementor-lite/elementor/assets/css/marvy-custom.css?ver=1.7.2.2' type='text/css' media='all' />
<link rel='stylesheet' id='marvy-custom-pro-css' href='http://blasusfoods.local/wp-content/plugins/marvy-animation-addons/elementor/assets/css/marvy-custom-pro.css?ver=1.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css' href='http://blasusfoods.local/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.4.2' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='mediaelement-css' href='http://blasusfoods.local/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.17' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='http://blasusfoods.local/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-default-style-css' href='http://blasusfoods.local/wp-content/themes/bridge/style.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-font_awesome-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/font-awesome/css/font-awesome.min.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-font_elegant-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/elegant-icons/style.min.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-linea_icons-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/linea-icons/style.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-dripicons-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/dripicons/dripicons.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-kiko-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/kiko/kiko-all.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-qode-font_awesome_5-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/font-awesome-5/css/font-awesome-5.min.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-stylesheet-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/stylesheet.min.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-print-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/print.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-style-dynamic-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/style_dynamic.css?ver=1723145762' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-responsive-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/responsive.min.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-style-dynamic-responsive-css' href='http://blasusfoods.local/wp-content/themes/bridge/css/style_dynamic_responsive.css?ver=1723145762' type='text/css' media='all' />
<style id='bridge-style-dynamic-responsive-inline-css' type='text/css'>
.header_top .q_social_icon_holder .simple_social{
line-height: 33px;
}

.qbutton:before{
content: '';
position: absolute;
left: 39px;
right: 42px;
height: 1px;
background-color: currentColor;
top: calc(50% - 1px);
}

.qode-title-with-lines .elementor-heading-title{
position: relative;
}

.qode-title-with-lines .elementor-heading-title:before, .qode-title-with-lines .elementor-heading-title:after{
content: '';
position: relative;
width: 18px;
height: 1px;
display: inline-block;
vertical-align: middle;
background-color: #9c9c9c;
}

.qode-title-with-lines .elementor-heading-title:before{
margin-right: 15px;
}

.qode-title-with-lines .elementor-heading-title:after{
margin-left: 15px;
}

div.wpcf7 .cf7_custom_style_1 .ajax-loader{
    display: none;
}

.qode-cf-button-wrapper {
    display: inline-block;
    margin: 8px 0 0;
    position: relative;
}

.qode-cf-button-wrapper:before{
    content: '';
    position: absolute;
    left: 33px;
    right: 37px;
    height: 1px;
    background-color: currentColor;
    top: calc(50% - 1px);
    z-index: 1;
}

.q_social_icon_holder:hover .simple_social{
color: #d8d8d8 !important;
}

.q_counter_holder p.counter_text{
margin: 1px 0 0;
}

.q_team .q_team_title_holder .q_team_name{
font-size: 19px;
font-weight: 400;
line-height: 1.1em;
margin: 0 0 3px;
}

.q_team .q_team_title_holder span{
font-family: 'Charmonman', sans-serif;
font-size: 15px;
font-weight: 700;
}

@media only screen and (max-width: 1000px){
.header_top p, .header_top .q_social_icon_holder .simple_social, header .header_top .q_social_icon_holder{
line-height: 20px;
}

.header_top{
padding: 20px 0 0;
}
}

@media only screen and (max-width: 768px){
.q_icon_list p {
padding: 0 0 0 38px;
}

.q_icon_list p, .q_list.number.circle_number li {
line-height: 27px;
}
}

.testimonials_holder .flex-direction-nav a:before{
font-size: 15px;
}

.testimonials_holder.light .flex-direction-nav a:before{
color: #939393;
}

.testimonials_holder.light .flex-direction-nav a{
border: none;
}

.testimonials_holder .flex-direction-nav a.flex-next:before{
content: "\f054";
}

.testimonials_holder .flex-direction-nav a.flex-prev:before{
content: "\f053";
}

.testimonials_holder .flex-direction-nav li:first-child{
margin-right: 8px;
}

.testimonials_holder .flex-direction-nav li:last-child{
margin-left: 8px;
}

.qode-pl-holder .qode-pli .qode-pli-title a{
font-size: 19px;
font-weight: 400;
}

.qode-pl-holder .qode-pli .qode-pli-price{
font-family: 'Charmonman', sans-serif;
font-size: 15px;
font-weight: 700;
color: #fff;
}

.portfolio_navigation .portfolio_next a, .portfolio_navigation .portfolio_prev a{
border: none;
background-color: transparent;
color: #939393;
font-size: 15px;
}

.portfolio_navigation .portfolio_next a:hover, .portfolio_navigation .portfolio_prev a:hover{
background-color: transparent;
background-image: none !important;
color: #939393;
}

.portfolio_navigation .portfolio_prev a .fa-angle-left:before{
content: '\f053';
}

.portfolio_navigation .portfolio_next a .fa-angle-right:before{
content: '\f054';
}

.projects_holder article .portfolio_description{
background-color: transparent;
}

.qode_portfolio_related .projects_holder article .portfolio_description .project_category{
color: #ffffff !important;
font-family: 'Charmonman', sans-serif;
font-size: 15px;
font-weight: 700;
}

.title .text_above_title:before, .title .text_above_title:after{
    content: '';
    position: relative;
    width: 18px;
    height: 1px;
    display: inline-block;
    vertical-align: middle;
    background-color: #9c9c9c;
}

.title .text_above_title:before{
    margin-right: 15px;
}

.title .text_above_title:after{
    margin-left: 15px;
}

.latest_post_two_holder .latest_post_two_inner{
    text-align: center;
}

.latest_post_two_holder .latest_post_two_text{
    padding: 19px 0 0;
}

.latest_post_two_holder .latest_post_two_info{
    border: none
}

.latest_post_two_holder .latest_post_two_info_inner .post_info_date, .latest_post_two_holder .latest_post_two_info_inner img, .latest_post_two_holder .latest_post_two_text .separator.small{
    display: none;
}

.latest_post_two_holder .latest_post_two_info_inner .post_info_author_name{
    color: #ffffff;
    font-family: 'Charmonman', sans-serif;
    font-size: 15px;
    font-weight: 700;
    text-transform: capitalize;
}

.latest_post_two_holder .latest_post_two_info{
    padding-top: 8px;
}

.latest_post_two_holder .latest_post_two_info_inner .post_info_author_name:before, .latest_post_two_holder .latest_post_two_info_inner .post_info_author_name:after{
    content: '';
    position: relative;
    width: 18px;
    height: 1px;
    display: inline-block;
    vertical-align: middle;
    background-color: #9c9c9c;
}

.latest_post_two_holder .latest_post_two_info_inner .post_info_author_name:before{
    margin-right: 15px;
}

.latest_post_two_holder .latest_post_two_info_inner .post_info_author_name:after{
    margin-left: 15px;
}

.latest_post_two_holder .latest_post_two_text .latest_post_two_title a:hover{
    color: #d8d8d8 !important;
}

.header_top {
    background-color: rgba(53, 53, 53, 1) !important;
}

.header_top{
height: 40px;
box-sizing: border-box;
padding-top:6px;
}

.q_icon_list:hover .qode-ili-icon-holder,
.q_icon_with_title:hover .icon_holder .qode_iwt_icon_holder i {
color: #6f6e6e !important;
}

.elementor-widget-container .q_icon_with_title {
display: flex;
align-items: center;
margin: 0 0 7px;
}
.elementor-widget-container .q_icon_with_title .icon_holder {
margin-right:5px;
}
.elementor-widget-container .q_icon_with_title.tiny .icon_text_holder,
.elementor-widget-container .q_icon_with_title .icon_text_inner,
.elementor-widget-container .q_icon_with_title .icon_with_title_link{
padding: 0;
margin: 0;
}

.qode_portfolio_related h4 {
padding: 67px 0 55px;
}

.q_accordion_holder.accordion.boxed .ui-accordion-header{
background-color: #353535;
color: #fff;
font-family: 'Rokkitt', sans-serif;
}

.qode-single-product-summary .q_accordion_holder.accordion.boxed .ui-accordion-header .tab-title{
position: relative;
}

.qode-single-product-summary .q_accordion_holder.accordion.boxed .ui-accordion-header .tab-title:before{
content: '';
position: absolute;
left: -7px;
right: -7px;
height: 1px;
background-color: currentColor;
top: calc(50% - 1px);
transform: scaleX(0);
transition: all 0.3s ease;
}

.qode-single-product-summary .q_accordion_holder.accordion.boxed .ui-accordion-header:hover .tab-title:before,.qode-single-product-summary .q_accordion_holder.accordion.boxed .ui-accordion-header.ui-state-active .tab-title:before{
transform: scaleX(1);
}

.woocommerce .product .images {
margin-bottom: 131px;
}

.woocommerce div.product div.product_meta>.social_share_list_holder>span, .woocommerce div.product div.product_meta>span{
color: #bcbcbc;
}

footer .qode_icon_list_item .q_icon_list{
margin-bottom: 10px;
}

.widget #searchform{
background-color: #202020;
}

.blog_holder.blog_large_image h2, .blog_holder.blog_large_image h2 a, .blog_holder.blog_single article h2 {
font-size: 30px;
line-height: 1.25em;
}

.blog_holder article .post_text .post_text_inner {
padding: 55px 23px 35px;
}

.single_tags .tags_text h5,
.comment_number_inner h5{
color: #ffffff;
font-family: 'Charmonman', sans-serif;
font-size: 15px;
line-height: 20px;
font-style: normal;
font-weight: 700;
letter-spacing: 0px;
text-transform: capitalize;
}

.comment_holder {
padding: 28px 0 15px;
}

.q_accordion_holder.accordion .ui-accordion-header:hover{
color: #fff!important;
}

.woocommerce-page.single-product ul.products li.product a.product-category.product-info, .woocommerce ul.products li.product a.product-category.product-info{
padding-top: 25px;
}
@media only screen and (max-width: 1000px){
.header_top{
height: auto;
}
}
header:not(.with_hover_bg_color) nav.main_menu>ul>li:hover>a{
opacity: 1;
}

.qbutton:before, .qode-cf-button-wrapper:before{
transform: scaleX(0);
transition: all 0.3s ease;
}

nav.main_menu ul li a span.underline_dash, nav.vertical_menu ul li a span.underline_dash{
transform: translateX(-50%) scaleX(0);
transition: all 0.3s ease;
}

nav.main_menu ul li.active a span.underline_dash, nav.main_menu ul li:hover a span.underline_dash, nav.vertical_menu ul li.active a span.underline_dash, nav.vertical_menu ul li:hover a span.underline_dash{
transform: translateX(-50%) scaleX(1);
}

.qbutton:hover:before, .qode-cf-button-wrapper:hover:before{
transform: scaleX(1);
}

nav.main_menu ul li a span.underline_dash, nav.vertical_menu ul li a span.underline_dash{
opacity: 1;
background-color: #fff;
bottom: 7px;
}

.woocommerce ul.products li.product:hover .image-wrapper img {
    opacity: .6;
}
.woocommerce ul.products li.product, .woocommerce ul.products li.product a.product-category, .woocommerce-page ul.products li.product a.product-category {
    background-color: #000;
}
.woocommerce ul.products li.product:hover h6 {
    color: #818181!important;
}
.title .text_above_title{
margin: 0 0 0;
}
.qode-pl-holder .qode-pli-text-wrapper{
margin-bottom: 0;
}

.qode-pl-holder.qode-normal-space .qode-pl-outer .qode-pli{
padding-bottom: 25px;
}
.latest_post_two_holder .latest_post_two_image a{
overflow: hidden;
}

.latest_post_two_holder .latest_post_two_image a:before{
content: '';
position: absolute;
top: 0;
left: 0;
height: 100%;
width: 100%;
background-color: rgba(0,0,0,.35);
opacity: 0;
-webkit-transition: opacity .4s ease;
transition: opacity .4s ease;
z-index: 1;
}

.latest_post_two_holder .latest_post_two_image a:hover:before{
opacity: 1;
}

.latest_post_two_holder .latest_post_two_image a img{
transition: transform .4s ease;
}

.latest_post_two_holder .latest_post_two_image a:hover img{
transform: scale(1.05);
}
.elementor-widget-container .q_icon_with_title .icon_holder {
    margin-right: 14px;
}
aside.sidebar h6.latest_post_title.entry_title a {
    font-family: "Rokkitt", sans-serif;
    font-size: 16px;
    letter-spacing: 0px;
    font-weight: 400;
    text-transform: uppercase;
    color: #ffffff;
    font-style: normal;
}
aside.sidebar h6.latest_post_title.entry_title a:hover {
    color: #818181! important;
}
aside .widget h5:not(.latest_post_title), .wpb_widgetised_column .widget h5:not(.latest_post_title) {
    font-family: "Rokkitt", sans-serif;
    font-size: 19px;
    letter-spacing: 0px;
    font-weight: 400;
    text-transform: uppercase;
    color: #ffffff;
    font-style: normal;
}
.single_tags .tags_text h5, .comment_number_inner h5 {
    color: #ffffff;
    font-family: 'Rokkitt', sans-serif;
    font-size: 18px;
    line-height: 20px;
    font-style: normal;
    font-weight: 500;
    letter-spacing: 0px;
    text-transform: uppercase;
}
h5.blockquote-text {
    color: #ffffff;
    font-family: 'Charmonman', sans-serif;
    font-size: 18px;
    font-weight: 700;
    text-transform: none;
    line-height: 31px;
}
.testimonials_holder.light .flex-direction-nav a:before{
transition: all 0.2s ease;
}

.testimonials_holder.light .flex-direction-nav a:hover:before{
color: #fff;
}
.qode-pl-holder.qode-info-below-image .qode-pli .qode-pli-text-wrapper .qode-pli-add-to-cart a:hover {
    color: #fff;
}
.portfolio_detail .info h6 {
     font-family: "Rokkitt", sans-serif;
    font-size: 16px;
    letter-spacing: 0px;
    font-weight: 400;
    text-transform: uppercase;
    color: #ffffff;
    font-style: normal;
}
.blog_holder article:not(.format-quote):not(.format-link) .post_info a:hover {
    color: #818181! important;
}
article:not(.format-quote):not(.format-link) .blog_like a:hover span {
    color: #818181! important;
}
.portfolio_navigation .portfolio_next a:hover, .portfolio_navigation .portfolio_prev a:hover {
    color: #fff;
}
nav.mobile_menu ul li, nav.mobile_menu ul li ul li{
border-bottom: none;
}
</style>
<link rel='stylesheet' id='js_composer_front-css' href='http://blasusfoods.local/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-style-handle-google-fonts-css' href='http://fonts.googleapis.com/css?family=Raleway%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100italic%2C300italic%2C400italic%2C700italic%7CRokkitt%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100italic%2C300italic%2C400italic%2C700italic%7CCharmonman%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100italic%2C300italic%2C400italic%2C700italic%7CRaleway%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%2C100italic%2C300italic%2C400italic%2C700italic&#038;subset=latin%2Clatin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-core-dashboard-style-css' href='http://blasusfoods.local/wp-content/plugins/bridge-core/modules/core-dashboard/assets/css/core-dashboard.min.css?ver=6.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='bridge-childstyle-css' href='http://blasusfoods.local/wp-content/themes/bridge-child/style.css?ver=6.5.3' type='text/css' media='all' />
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/ScrollToPlugin.min.js?ver=6.5.3" id="ScrollToPlugin-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" id="layerslider-utils-js-extra">
/* <![CDATA[ */
var LS_Meta = {"v":"6.11.5","fixGSAP":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/plugins/LayerSlider/assets/static/layerslider/js/layerslider.utils.js?ver=6.11.5" id="layerslider-utils-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/plugins/LayerSlider/assets/static/layerslider/js/layerslider.kreaturamedia.jquery.js?ver=6.11.5" id="layerslider-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/plugins/LayerSlider/assets/static/layerslider/js/layerslider.transitions.js?ver=6.11.5" id="layerslider-transitions-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.4.2" id="tp-tools-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.4.2" id="revmin-js"></script>
<meta name="generator" content="Powered by LayerSlider 6.11.5 - Multi-Purpose, Responsive, Parallax, Mobile-Friendly Slider Plugin for WordPress." />
<!-- LayerSlider updates and docs at: https://layerslider.kreaturamedia.com -->
<link rel="https://api.w.org/" href="http://blasusfoods.local/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://blasusfoods.local/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.5.3" />
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 6.4.2 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="http://blasusfoods.local/wp-content/uploads/2024/05/cropped-Picsart_24-05-31_03-32-01-562-32x32.png" sizes="32x32" />
<link rel="icon" href="http://blasusfoods.local/wp-content/uploads/2024/05/cropped-Picsart_24-05-31_03-32-01-562-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="http://blasusfoods.local/wp-content/uploads/2024/05/cropped-Picsart_24-05-31_03-32-01-562-180x180.png" />
<meta name="msapplication-TileImage" content="http://blasusfoods.local/wp-content/uploads/2024/05/cropped-Picsart_24-05-31_03-32-01-562-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}				
					if(window.rs_init_css===undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));					
					document.getElementById(e.c).height = newh+"px";
					window.rs_init_css.innerHTML += "#"+e.c+"_wrapper { height: "+newh+"px }";				
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<body class="error404 bridge-core-2.6.8 qode-page-transition-enabled ajax_leftright page_not_loaded qode-page-loading-effect-enabled  qode_grid_1300 footer_responsive_adv qode-content-sidebar-responsive qode-overridden-elementors-fonts qode_disabled_responsive_button_padding_change qode-child-theme-ver-1.0.0 qode-theme-ver-25.3 qode-theme-bridge disabled_footer_bottom wpb-js-composer js-comp-ver-6.6.0 vc_responsive elementor-default elementor-kit-444" itemscope itemtype="http://schema.org/WebPage">



		<div class="qode-page-loading-effect-holder">
		<div class="ajax_loader"><div class="ajax_loader_1"><div class="rotating_cubes"><div class="cube1"></div><div class="cube2"></div></div></div></div>
			</div>
	
<div class="wrapper">
	<div class="wrapper_inner">

    
		<!-- Google Analytics start -->
				<!-- Google Analytics end -->

		
	<header class=" scroll_header_top_area  stick_with_left_right_menu scrolled_not_transparent page_header">
	<div class="header_inner clearfix">
				<div class="header_top_bottom_holder">
			
			<div class="header_bottom clearfix" style=' background-color:rgba(0, 0, 0, 1);' >
																			<nav class="main_menu drop_down left_side">
									<ul id="menu-main-menu-left" class=""><li id="nav-menu-item-438" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home  narrow"><a href="http://blasusfoods.local/" class=""><i class="menu_icon dripicons-home fa"></i><span>Home<span class="underline_dash"></span></span><span class="plus"></span></a></li>
<li id="nav-menu-item-513" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://blasusfoods.local/products/" class=""><i class="menu_icon dripicons-photo-group fa"></i><span>Products<span class="underline_dash"></span></span><span class="plus"></span></a></li>
</ul>								</nav>
														<div class="header_inner_left">
																	<div class="mobile_menu_button">
		<span>
			<i class="qode_icon_font_awesome fa fa-bars " ></i>		</span>
	</div>
								<div class="logo_wrapper" >
	<div class="q_logo">
		<a itemprop="url" href="http://blasusfoods.local/" >
             <img itemprop="image" class="normal" src="http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562.png" alt="Logo"> 			 <img itemprop="image" class="light" src="http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562.png" alt="Logo"/> 			 <img itemprop="image" class="dark" src="http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562.png" alt="Logo"/> 			 <img itemprop="image" class="sticky" src="http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562.png" alt="Logo"/> 			 <img itemprop="image" class="mobile" src="http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562.png" alt="Logo"/> 					</a>
	</div>
	</div>															</div>
															<nav class="main_menu drop_down right_side">
									<ul id="menu-main-menu-right" class=""><li id="nav-menu-item-514" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://blasusfoods.local/about-us/" class=""><i class="menu_icon icon_quotations fa"></i><span>About Us<span class="underline_dash"></span></span><span class="plus"></span></a></li>
<li id="nav-menu-item-441" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://blasusfoods.local/contact/" class=""><i class="menu_icon dripicons-phone fa"></i><span>Contact<span class="underline_dash"></span></span><span class="plus"></span></a></li>
</ul>								</nav>
														<nav class="mobile_menu">
	<ul><li id="mobile-menu-item-438" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="http://blasusfoods.local/" class=""><span>Home</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-513" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://blasusfoods.local/products/" class=""><span>Products</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-514" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://blasusfoods.local/about-us/" class=""><span>About Us</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-441" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://blasusfoods.local/contact/" class=""><span>Contact</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
</ul></nav>
											</div>
			</div>
		</div>

</header>	<a id="back_to_top" href="#">
        <span class="fa-stack">
            <i class="qode_icon_font_awesome fa fa-angle-up " ></i>        </span>
	</a>
	
	
    
    	
    
    <div class="content ">
            <div class="meta">

            
        <div class="seo_title">  Page not found</div>

        


                        
            <span id="qode_page_id">-1</span>
            <div class="body_classes">error404,bridge-core-2.6.8,qode-page-transition-enabled,ajax_leftright,page_not_loaded,qode-page-loading-effect-enabled,,qode_grid_1300,footer_responsive_adv,qode-content-sidebar-responsive,qode-overridden-elementors-fonts,qode_disabled_responsive_button_padding_change,qode-child-theme-ver-1.0.0,qode-theme-ver-25.3,qode-theme-bridge,disabled_footer_bottom,wpb-js-composer js-comp-ver-6.6.0,vc_responsive,elementor-default,elementor-kit-444</div>
        </div>
        <div class="content_inner  ">
    <style type="text/css" id="stylesheet-inline-css--1">   .error404.disabled_footer_top .footer_top_holder, .error404.disabled_footer_bottom .footer_bottom_holder { display: none;}

</style>
				<div class="title_outer title_without_animation"    data-height="200">
		<div class="title title_size_small  position_center " style="height:200px;">
			<div class="image not_responsive"></div>
										<div class="title_holder"  style="padding-top:100px;height:100px;">
					<div class="container">
						<div class="container_inner clearfix">
								<div class="title_subtitle_holder" >
                                                                																		<h1 ><span>404 - Page not found</span></h1>
																	
																										                                                            </div>
						</div>
					</div>
				</div>
								</div>
			</div>
			<div class="container">
                				<div class="container_inner default_template_holder">
					<div class="page_not_found">
						<h2> The page you are looking for is not found </h2>
                        <p> The page you are looking for does not exist. It may have been moved, or removed altogether. Perhaps you can return back to the site&#039;s homepage and see if you can find what you are looking for. </p>
						<div class="separator  transparent center  " style="margin-top:35px;"></div>
						<p><a itemprop="url" class="qbutton with-shadow" href="http://blasusfoods.local/"> Back to homepage </a></p>
						<div class="separator  transparent center  " style="margin-top:35px;"></div>
					</div>
				</div>
                			</div>
		
	</div>
</div>



	<footer >
		<div class="footer_inner clearfix">
				<div class="footer_top_holder">
            			<div class="footer_top">
								<div class="container">
					<div class="container_inner">
																	<div class="two_columns_50_50 clearfix">
								<div class="column1">
									<div class="column_inner">
										<div class="two_columns_50_50 clearfix">
											<div class="column1 footer_col1">
												<div class="column_inner">
													<div id="text-2" class="widget widget_text">			<div class="textwidget"><p><img loading="lazy" decoding="async" class="alignnone  wp-image-461" src="http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562-187x300.png" alt="" width="115" height="184" srcset="http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562-187x300.png 187w, http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562-640x1024.png 640w, http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562-700x1120.png 700w, http://blasusfoods.local/wp-content/uploads/2024/05/Picsart_24-05-31_03-32-01-562.png 703w" sizes="(max-width: 115px) 100vw, 115px" /></p>
</div>
		</div><div class="widget qode_separator_widget" style="margin-bottom: 24px;"></div>												</div>
											</div>
											<div class="column2 footer_col2">
												<div class="column_inner">
													<div id="text-4" class="widget widget_text"><h5>stay in touch</h5>			<div class="textwidget"></div>
		</div><div class="widget qode_icon_list_item"><div class="q_icon_list"><i class="qode_icon_font_awesome fa fa-flag qode-ili-icon-holder transparent" style="font-size: 17px;color: #515151;" ></i><p style="color:#ffffff;font-size: 14px;font-weight: 400;">BlasusFoods</p></div></div><div class="widget qode_icon_list_item"><div class="q_icon_list"><i class="qode_icon_font_awesome fa fa-thumb-tack qode-ili-icon-holder transparent" style="color: #515151;" ></i><p style="color:#ffffff;font-size: 14px;font-weight: 400;">Hadgud Road, Post: Hadgud - 388110, Ta: Anand</p></div></div><div class="widget qode_icon_list_item"><div class="q_icon_list"><i class="qode_icon_font_awesome fa fa-phone qode-ili-icon-holder transparent" style="color: #515151;" ></i><p style="color:#ffffff;font-size: 14px;font-weight: 400;">+91 9687777963</p></div></div><div class="widget qode_icon_list_item"><div class="q_icon_list"><i class="qode_icon_font_awesome fa fa-envelope qode-ili-icon-holder transparent" style="color: #515151;" ></i><p style="color:#ffffff;font-size: 14px;font-weight: 400;">rbharthu@outlook.com</p></div></div>												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="column2 footer_col3">
									<div class="column_inner">
																			</div>
								</div>
							</div>							
															</div>
				</div>
							</div>
					</div>
							<div class="footer_bottom_holder">
                									<div class="footer_bottom">
							<div class="textwidget"><h6>© Copyright Blasusfoods 2024</h6>
</div>
					</div>
								</div>
				</div>
	</footer>
		
</div>
</div>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.9.5" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"http:\/\/blasusfoods.local\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.9.5" id="contact-form-7-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/jquery/ui/accordion.min.js?ver=1.13.2" id="jquery-ui-accordion-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/jquery/ui/tabs.min.js?ver=1.13.2" id="jquery-ui-tabs-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/doubletaptogo.js?ver=6.5.3" id="doubleTapToGo-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/modernizr.min.js?ver=6.5.3" id="modernizr-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.appear.js?ver=6.5.3" id="appear-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/counter.js?ver=6.5.3" id="counter-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/easypiechart.js?ver=6.5.3" id="easyPieChart-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/mixitup.js?ver=6.5.3" id="mixItUp-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.prettyPhoto.js?ver=6.5.3" id="prettyphoto-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.fitvids.js?ver=6.5.3" id="fitvids-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.flexslider-min.js?ver=6.5.3" id="flexslider-js"></script>
<script type="text/javascript" id="mediaelement-core-js-before">
/* <![CDATA[ */
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
/* ]]> */
</script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.17" id="mediaelement-core-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=6.5.3" id="mediaelement-migrate-js"></script>
<script type="text/javascript" id="mediaelement-js-extra">
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive","audioShortcodeLibrary":"mediaelement","videoShortcodeLibrary":"mediaelement"};
/* ]]> */
</script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=6.5.3" id="wp-mediaelement-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/infinitescroll.min.js?ver=6.5.3" id="infiniteScroll-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.waitforimages.js?ver=6.5.3" id="waitforimages-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-includes/js/jquery/jquery.form.min.js?ver=4.3.0" id="jquery-form-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/waypoints.min.js?ver=6.5.3" id="waypoints-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jplayer.min.js?ver=6.5.3" id="jplayer-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/bootstrap.carousel.js?ver=6.5.3" id="bootstrapCarousel-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/skrollr.js?ver=6.5.3" id="skrollr-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/Chart.min.js?ver=6.5.3" id="charts-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.easing.1.3.js?ver=6.5.3" id="easing-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/abstractBaseClass.js?ver=6.5.3" id="abstractBaseClass-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.countdown.js?ver=6.5.3" id="countdown-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.multiscroll.min.js?ver=6.5.3" id="multiscroll-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.justifiedGallery.min.js?ver=6.5.3" id="justifiedGallery-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/bigtext.js?ver=6.5.3" id="bigtext-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.sticky-kit.min.js?ver=6.5.3" id="stickyKit-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/owl.carousel.min.js?ver=6.5.3" id="owlCarousel-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/typed.js?ver=6.5.3" id="typed-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.carouFredSel-6.2.1.min.js?ver=6.5.3" id="carouFredSel-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/lemmon-slider.min.js?ver=6.5.3" id="lemmonSlider-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.fullPage.min.js?ver=6.5.3" id="one_page_scroll-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.mousewheel.min.js?ver=6.5.3" id="mousewheel-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.touchSwipe.min.js?ver=6.5.3" id="touchSwipe-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.isotope.min.js?ver=6.5.3" id="isotope-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/packery-mode.pkgd.min.js?ver=6.5.3" id="packery-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.stretch.js?ver=6.5.3" id="stretch-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/imagesloaded.js?ver=6.5.3" id="imagesLoaded-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/rangeslider.min.js?ver=6.5.3" id="rangeSlider-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.event.move.js?ver=6.5.3" id="eventMove-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/jquery.twentytwenty.js?ver=6.5.3" id="twentytwenty-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6" id="swiper-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/TweenLite.min.js?ver=6.5.3" id="TweenLite-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/smoothPageScroll.min.js?ver=6.5.3" id="smoothPageScroll-js"></script>
<script type="text/javascript" id="bridge-default-dynamic-js-extra">
/* <![CDATA[ */
var no_ajax_obj = {"no_ajax_pages":["","http:\/\/blasusfoods.local\/wp-login.php?action=logout&_wpnonce=5f0684719f"]};
/* ]]> */
</script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/default_dynamic.js?ver=1723145762" id="bridge-default-dynamic-js"></script>
<script type="text/javascript" id="bridge-default-js-extra">
/* <![CDATA[ */
var QodeAdminAjax = {"ajaxurl":"http:\/\/blasusfoods.local\/wp-admin\/admin-ajax.php"};
var qodeGlobalVars = {"vars":{"qodeAddingToCartLabel":"Adding to Cart...","page_scroll_amount_for_sticky":false}};
/* ]]> */
</script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/default.min.js?ver=6.5.3" id="bridge-default-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/ajax.min.js?ver=6.5.3" id="bridge-ajax-js"></script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.6.0" id="wpb_composer_front_js-js"></script>
<script type="text/javascript" id="qode-like-js-extra">
/* <![CDATA[ */
var qodeLike = {"ajaxurl":"http:\/\/blasusfoods.local\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="http://blasusfoods.local/wp-content/themes/bridge/js/plugins/qode-like.min.js?ver=6.5.3" id="qode-like-js"></script>
</body>
</html>